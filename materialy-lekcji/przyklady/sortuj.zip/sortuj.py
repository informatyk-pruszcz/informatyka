liczby = [5, 2, 4, 2]
for i in range(len(liczby) - 1):
    najm = i
    for j in range(i + 1, len(liczby)):
        if liczby[j] < liczby[najm]:
            najm = j
    liczby[i], liczby[najm] = liczby[najm], liczby[i]
print(liczby)
