wyniki = [2, 5, 7, 5]
licznik = 0
for punkty in wyniki:
    if punkty >= 5:
        licznik += 1
print(licznik)
