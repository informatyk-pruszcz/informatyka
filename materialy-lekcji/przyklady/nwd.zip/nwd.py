a = 48
b = 18
while b != 0:
    reszta = a % b
    a, b = b, reszta
print(a)
