rundy = int(input("Liczba rund: "))
minuty = rundy * 5
print(minuty)
