lista = [4, 2, 4, 9]
szukana = 4
pozycja = -1
for i in range(len(lista)):
    if lista[i] == szukana:
        pozycja = i
        break
print(pozycja)
